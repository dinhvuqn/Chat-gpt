# Flask Wheel Demo
A simple Flask app packaged as a wheel.