from setuptools import setup, find_packages

setup(
    name="flask_wheel_demo",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "flask",
        "waitress"
    ],
    entry_points={
        "console_scripts": [
            "flask-wheel-run = flask_wheel_demo.app:run"
        ]
    },
)
