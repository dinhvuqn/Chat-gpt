# evidence_export.py
# -*- coding: utf-8 -*-

from pathlib import Path
from typing import Dict, List, Tuple, Optional, Callable, Union
from io import BytesIO

from PIL import Image as PILImage
from openpyxl import Workbook
from openpyxl.drawing.image import Image as XLImage
from openpyxl.styles import Font, PatternFill, Alignment
from openpyxl.utils import get_column_letter
from tempfile import NamedTemporaryFile
from pathlib import Path
from PIL import Image as PILImage
import os

SUPPORTED_EXTS = {".png", ".jpg", ".jpeg"}

# Styles
_HEADER_FILL = PatternFill(start_color="DDDDDD", end_color="DDDDDD", fill_type="solid")
_BOLD = Font(bold=True)
_CENTER = Alignment(horizontal="center", vertical="center", wrap_text=True)
_WRAP = Alignment(vertical="center", wrap_text=True)

# Column widths
_TEXT_WIDTHS = {
    "A": 28,   # Scenario
    "B": 34,   # Image name
    "C": 22,   # Version A (path or link)
    "D": 22,   # Version B (path or link)
    "E": 16,   # Status
}
_IMG_COL_WIDTH = 52
_ROW_PADDING_PT = 18  # extra padding for row height

def _resize_to_temp_png(src: Path, max_width_px: int) -> str:
    """
    Resize ảnh theo max_width, lưu ra file .png tạm.
    Trả về đường dẫn file .png tạm (string).
    """
    im = PILImage.open(src).convert("RGBA")
    w, h = im.size
    if w > max_width_px:
        scale = max_width_px / float(w)
        im = im.resize((int(w * scale), int(h * scale)), PILImage.LANCZOS)

    tmp = NamedTemporaryFile(delete=False, suffix=".png")
    tmp_path = tmp.name
    tmp.close()
    im.save(tmp_path, format="PNG")
    return tmp_path


def _px_to_row_height(px: int) -> float:
    """Approx convert px to Excel points, with a bit of padding."""
    return px * 0.75 + _ROW_PADDING_PT


def _resize_pil_to_max_width(path: Path, max_width_px: int) -> PILImage.Image:
    """
    Open image and (if needed) resize proportionally to max_width.
    Return a PIL Image (RGBA) — no temp files.
    """
    im = PILImage.open(path)
    im = im.convert("RGBA")
    w, h = im.size
    if w > max_width_px:
        scale = max_width_px / float(w)
        im = im.resize((int(w * scale), int(h * scale)), PILImage.LANCZOS)
    return im


def _list_images(folder: Path) -> Dict[str, Path]:
    """Return dict: {filename: Path} for images directly under `folder`."""
    if not folder.exists():
        return {}
    out = {}
    for p in folder.iterdir():
        if p.is_file() and p.suffix.lower() in SUPPORTED_EXTS:
            out[p.name] = p
    return out


def compare_feature_pairs(
    root_dir: Union[str, Path],
    platform: str,
    feature: str,
    version_a: str,
    version_b: str,
) -> Dict[str, List[Tuple[Optional[Path], Optional[Path]]]]:
    """
    So khớp ảnh theo MỘT feature giữa 2 version, nhóm theo scenario.
    Trả về:
      { scenario_name: [(path_a | None, path_b | None), ...] }
    Bắt cặp theo TÊN FILE trong cùng scenario.
    """
    root = Path(root_dir)
    # Nếu truyền parent của 'evidence', tự động nối thêm
    if root.name != "evidence" and (root / "evidence").exists():
        root = root / "evidence"

    base_a = root / platform / version_a / feature
    base_b = root / platform / version_b / feature

    scenarios = set()
    if base_a.exists():
        scenarios.update([p.name for p in base_a.iterdir() if p.is_dir()])
    if base_b.exists():
        scenarios.update([p.name for p in base_b.iterdir() if p.is_dir()])

    result: Dict[str, List[Tuple[Optional[Path], Optional[Path]]]] = {}
    for scenario in sorted(scenarios):
        sc_a = base_a / scenario
        sc_b = base_b / scenario

        imgs_a = _list_images(sc_a)
        imgs_b = _list_images(sc_b)

        all_names = sorted(set(imgs_a.keys()) | set(imgs_b.keys()))
        pairs: List[Tuple[Optional[Path], Optional[Path]]] = []
        for name in all_names:
            pairs.append((imgs_a.get(name), imgs_b.get(name)))

        result[scenario] = pairs

    return result

import re

def generate_feature_compare_excel(
    root_dir,
    platform: str,
    feature: str,
    version_a: str,   # NEW
    version_b: str,   # OLD
    *,
    max_width_px: int = 320,
    link_builder=None,
) -> bytes:
    """
    Xuất Excel, mỗi scenario là một sheet:
      A: Feature (merge toàn bộ khối)
      B: Scenario (merge theo từng scenario nếu có nhiều ảnh)
      C: NEW (version_a)
      D: (cột trống)
      E: OLD (version_b)

    - Tên sheet bắt buộc dạng "TC_xx" (xx = 01, 02, ...)
    - Ảnh gốc (không chỉnh sửa file)
    - Giữa mỗi ảnh có 1 hàng trống
    - Gridlines tắt
    """
    data = compare_feature_pairs(root_dir, platform, feature, version_a, version_b)
    if not data:
        raise FileNotFoundError(
            f"Không tìm thấy scenario nào trong:\n"
            f"- {Path(root_dir)/platform/{version_a}/{feature}}\n"
            f"- {Path(root_dir)/platform/{version_b}/{feature}}"
        )

    wb = Workbook()
    default_ws = wb.active
    wb.remove(default_ws)

    def _px_to_col_width(px: int) -> float:
        return (px - 5) / 7.0 if px > 0 else 15.0

    # Chuẩn hóa scenario: lấy prefix TC_xx và sort theo số
    scenarios_sorted = []
    for scenario in data.keys():
        m = re.match(r"(TC[_\- ]?(\d+))", scenario, re.IGNORECASE)
        if m:
            tc_id = int(m.group(2))
            tc_name = f"TC_{tc_id:02d}"
        else:
            tc_id = 9999
            tc_name = scenario[:31]
        scenarios_sorted.append((tc_id, tc_name, scenario))

    scenarios_sorted.sort(key=lambda x: x[0])

    for _, sheet_name, scenario in scenarios_sorted:
        pairs = data[scenario]

        ws = wb.create_sheet(title=sheet_name)

        # Header
        headers = ["Feature", "Scenario", f"NEW ({version_a})", "", f"OLD ({version_b})"]
        ws.append(headers)
        for col_idx in range(1, len(headers) + 1):
            c = ws.cell(row=1, column=col_idx)
            c.font = _BOLD
            c.fill = _HEADER_FILL
            c.alignment = _CENTER

        ws.column_dimensions["A"].width = 22
        ws.column_dimensions["B"].width = 28

        # Tính width ảnh
        max_px_new = 0
        max_px_old = 0
        for path_a, path_b in pairs:
            if path_a and path_a.exists():
                try:
                    with PILImage.open(path_a) as im:
                        max_px_new = max(max_px_new, im.size[0])
                except Exception:
                    pass
            if path_b and path_b.exists():
                try:
                    with PILImage.open(path_b) as im:
                        max_px_old = max(max_px_old, im.size[0])
                except Exception:
                    pass

        ws.column_dimensions["C"].width = _px_to_col_width(max_px_new)
        ws.column_dimensions["E"].width = _px_to_col_width(max_px_old)
        ws.column_dimensions["D"].width = 5

        current_row = 2
        scenario_start = current_row

        for idx_img, (path_a, path_b) in enumerate(pairs, start=1):
            if idx_img == 1:
                ws.cell(current_row, 2, scenario).alignment = _WRAP

            max_h_px = 0

            # NEW (version_a) -> C
            if path_a and path_a.exists():
                ws.add_image(XLImage(str(path_a)), f"C{current_row}")
                try:
                    with PILImage.open(path_a) as imh:
                        max_h_px = max(max_h_px, imh.size[1])
                except Exception:
                    pass

            # OLD (version_b) -> E
            if path_b and path_b.exists():
                ws.add_image(XLImage(str(path_b)), f"E{current_row}")
                try:
                    with PILImage.open(path_b) as imh:
                        max_h_px = max(max_h_px, imh.size[1])
                except Exception:
                    pass

            if max_h_px > 0:
                ws.row_dimensions[current_row].height = _px_to_row_height(max_h_px)

            current_row += 1
            ws.row_dimensions[current_row].height = 8
            current_row += 1

        scenario_end = current_row - 1
        if scenario_end > scenario_start:
            ws.merge_cells(start_row=scenario_start, start_column=2,
                           end_row=scenario_end, end_column=2)
            sc_cell = ws.cell(scenario_start, 2)
            sc_cell.alignment = Alignment(vertical="center", horizontal="center", wrap_text=True)

            ws.merge_cells(start_row=scenario_start, start_column=1,
                           end_row=scenario_end, end_column=1)
            feat_cell = ws.cell(scenario_start, 1, feature)
            feat_cell.alignment = Alignment(vertical="center", horizontal="center", wrap_text=True)
            feat_cell.font = _BOLD

        ws.freeze_panes = "A2"
        ws.sheet_view.showGridLines = False
        ws.sheet_view.zoomScale = 60

    with NamedTemporaryFile(delete=False, suffix=".xlsx") as tmp:
        temp_xlsx = tmp.name
    try:
        wb.save(temp_xlsx)
        with open(temp_xlsx, "rb") as f:
            xlsx_bytes = f.read()
    finally:
        try:
            os.unlink(temp_xlsx)
        except OSError:
            pass

    return xlsx_bytes
