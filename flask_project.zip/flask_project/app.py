from io import BytesIO
from flask import Flask, render_template, request, send_file
from evidence_export import generate_feature_compare_excel

app = Flask(__name__)

@app.route("/")
def index():
    # Trang HTML có form nhập tham số và nút Export
    return render_template("export.html")

@app.route("/export-evidence")
def export_evidence():
    # Lấy tham số từ form (method GET)
    root = request.args.get("root", "./evidence")
    platform = request.args.get("platform")
    feature = request.args.get("feature")
    va = request.args.get("va")  # version A
    vb = request.args.get("vb")  # version B
    max_width = int(request.args.get("max_width", 320))

    if not all([platform, feature, va, vb]):
        return "Thiếu tham số platform/feature/va/vb", 400

    # Tạo file Excel trong bộ nhớ
    xlsx_bytes = generate_feature_compare_excel(
        root_dir=root,
        platform=platform,
        feature=feature,
        version_a=va,
        version_b=vb,
        max_width_px=max_width,
        link_builder=None,  # hoặc truyền hàm chuyển Path -> URL nếu bạn host ảnh
    )

    filename = f"{platform}_{feature}_{va}_vs_{vb}.xlsx"
    return send_file(
        BytesIO(xlsx_bytes),
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
        as_attachment=True,
        download_name=filename,
    )

if __name__ == "__main__":
    app.run(debug=True)
